package com.example.demo;

import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class RateLimiterService {

    private static final int MAX_REQUESTS = 5;
    private static final long TIME_WINDOW_MS = 60 * 1000; // 1 minute

    private final Map<String, UserRequests> requestsMap = new ConcurrentHashMap<>();

    public boolean isAllowed(String ip) {
        long now = Instant.now().toEpochMilli();
        requestsMap.putIfAbsent(ip, new UserRequests(0, now));

        UserRequests userRequests = requestsMap.get(ip);

        synchronized (userRequests) {
            if (now - userRequests.startTime > TIME_WINDOW_MS) {
                userRequests.startTime = now;
                userRequests.count = 1;
                return true;
            } else {
                if (userRequests.count < MAX_REQUESTS) {
                    userRequests.count++;
                    return true;
                } else {
                    return false;
                }
            }
        }
    }

    public long getRetryAfter(String ip) {
        long now = Instant.now().toEpochMilli();
        UserRequests userRequests = requestsMap.get(ip);
        return Math.max(0, TIME_WINDOW_MS - (now - userRequests.startTime)) / 1000;
    }

    private static class UserRequests {
        int count;
        long startTime;

        UserRequests(int count, long startTime) {
            this.count = count;
            this.startTime = startTime;
        }
    }
}
