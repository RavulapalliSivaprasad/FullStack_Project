package com.example.demo;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;

import java.util.Random;

@RestController
public class QuoteController {

    private final RateLimiterService rateLimiterService;
    private final String[] quotes = {
            "The only way to do great work is to love what you do. - Steve Jobs",
            "Success is not final, failure is not fatal: It is the courage to continue that counts. - Winston Churchill",
            "Believe you can and you're halfway there. - Theodore Roosevelt",
            "Do what you can, with what you have, where you are. - Theodore Roosevelt",
            "Your time is limited, so don’t waste it living someone else’s life. - Steve Jobs"
    };

    public QuoteController(RateLimiterService rateLimiterService) {
        this.rateLimiterService = rateLimiterService;
    }

    @GetMapping("/api/quote")
    public ResponseEntity<?> getQuote(HttpServletRequest request) {
        String ip = request.getRemoteAddr();

        if (!rateLimiterService.isAllowed(ip)) {
            long retryAfter = rateLimiterService.getRetryAfter(ip);
            return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS)
                    .body("{\"error\": \"Rate limit exceeded. Try again in " + retryAfter + " seconds.\"}");
        }

        Random random = new Random();
        String quote = quotes[random.nextInt(quotes.length)];
        return ResponseEntity.ok("{\"quote\": \"" + quote + "\"}");
    }
}
